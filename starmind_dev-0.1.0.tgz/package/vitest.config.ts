import { defineConfig } from 'vitest/config';
import { resolve } from 'path';

/**
 * This package's first test config.
 *
 * The `alias` is the third place `@kcd/core` is pointed at kcd_sdk's source — beside tsconfig `paths`
 * for the checker and build.js for the bundler. Three declarations of one fact is one too many and is
 * noted rather than tidied: collapsing them needs a shared config module, which is a change to the
 * daedalus-derived build shape rather than to this file, and doing it here would leave that shape
 * inconsistent across two packages instead of one.
 */
export default defineConfig( {
	resolve: {
		alias: { '@kcd/core': resolve( __dirname, '..', 'kcd_sdk', 'src', 'core', 'index.ts' ) }
	},
	test: {
		name:        'starmind_dev',
		environment: 'node',
		include:     [ 'src/**/*.test.ts' ],
		exclude:     [ '**/node_modules/**', '**/dist/**' ]
	}
} );
