import { randomUUID } from 'crypto';

import { Agent, type SerializedAgent, type ToolDef } from '@kcd/core';

import { Door, isOk, unreached, type DoorReply } from '../Door';
import type { ToolDefinition, ToolResult } from '../mcp';

/**
 * The HOT tools — everything that needs a running Starmind.
 *
 * These are the nine that used to live INSIDE the application as an in-process tool table. Nothing
 * about what they do has changed; what changed is which side of the process boundary they run on, and
 * that single move is the whole of Arc 1. Re-read the cold-tools header for the other half.
 *
 * ── STILL THIN CALLERS, UNDER A COST THAT WENT UP ───────────────────────────────────────────────
 *
 * The founding rule of this surface was that every handler is argument-shaping over a bus verb the
 * RENDERER already calls, so that a test exercises the road the product ships rather than a private
 * one built for testing. That rule was FREE when a verb was a function call in the same process. It is
 * not free now — every verb is an HTTP round trip on loopback.
 *
 * IT IS KEPT ANYWAY, and the temptation it resists is worth naming because it will recur: batching two
 * verbs into one app-side helper, or caching app state on this side to save a hop, is how a second
 * implementation of the product gets born inside its own test rig. `spawn` costs three round trips. On
 * loopback that is single-digit milliseconds against a turn that takes thirty to ninety seconds, so
 * the optimization would buy nothing measurable and cost the only property that makes these tools
 * evidence.
 *
 * The corollary is unchanged and is now MORE useful, not less: anything this file cannot do through an
 * existing verb is a MISSING VERB, not licence to reach past it. Out of process, that signal got
 * sharper — in-process it was possible to quietly reach for a main-side object and never notice.
 *
 * ── FIRE AND FORGET, BECAUSE AGENTS WORK IN TURNS ───────────────────────────────────────────────
 *
 * A turn takes 30–90 seconds. Nothing here waits for one. `chat_send` is an emit-and-go bus event, so
 * these tools return the moment a turn is ACCEPTED, carrying the session id and a traceId, and the
 * caller reads the outcome afterwards from `get_turns` plus the trace files.
 *
 * ── WHAT THE MOVE COST, STATED PLAINLY ──────────────────────────────────────────────────────────
 *
 * In process, a reply from any of these tools was itself proof the app was alive. That is gone: this
 * server answers whether or not Starmind is running. `dev_status` is now the ONLY tool whose success
 * is a statement about the app, which is why it is the one to call first and why every other tool
 * reports being unable to reach the app as a distinct, named outcome rather than as a failure.
 */

/** JSON text is the return currency — every consumer here is a program or an agent asserting on
 *  fields, and a sentence would have to be parsed back. */
function ok( value: unknown ): ToolResult {
	return { content: [ { type: 'text', text: JSON.stringify( value, null, 2 ) } ] };
}

/** Refusals stay PROSE and say what would fix them — the one place this surface talks to a reader
 *  rather than a parser, and the reader is usually about to retry. */
function fail( reason: string ): ToolResult {
	return { content: [ { type: 'text', text: reason } ], isError: true };
}

/**
 * Turn any non-ok door reply into the tool's refusal, with the outcome kept intact.
 *
 * THE POINT IS THAT THESE DO NOT COLLAPSE. "The app is not running", "no service serves that verb" and
 * "the verb ran and threw" are three different things to go and fix, and a caller — human or agent —
 * decides what to do next from precisely that distinction. An unreached call additionally says NOTHING
 * WAS TESTED, because the most expensive mistake available here is reading a transport failure as a
 * finding about the app.
 */
function refuse( reply: DoorReply, tool: string ): ToolResult {
	const detail = 'detail' in reply ? reply.detail : '';
	if ( unreached( reply ) ) {
		return fail( `${ tool }: could not reach the app [ ${ reply.outcome } ]. NOTHING WAS TESTED — this is a fact about the connection, not about Starmind.\n\n${ detail }` );
	}
	return fail( `${ tool }: the app answered and the call did not succeed [ ${ reply.outcome } ] on \`${ reply.verb }\`.\n\n${ detail }` );
}

/** Ask one verb and hand back either its value or a finished refusal. The shape every tool below opens
 *  with, so the branch is written once rather than nine times with one of them subtly different. */
async function verb( name: string, tool: string, ...args: unknown[] ): Promise<{ value: unknown } | { refusal: ToolResult }> {
	const reply = await Door.request( name, ...args );
	if ( !isOk( reply ) ) return { refusal: refuse( reply, tool ) };
	return { value: reply.value };
}

/** The fields this surface reads off a session row. Named locally rather than importing the SDK's
 *  `Session`, because what crosses the door is the SERIALIZED form and typing it as the live class
 *  would claim behaviour that is not on the wire. */
interface SessionRef {
	id:         string;
	agentId:    string;
	title?:     string | null;
	status?:    string;
	turnCount?: number;
}

/**
 * Resolve an agent reference to a REHYDRATED Agent, by id or exact name.
 *
 * ── THIS FUNCTION IS THE ANSWER TO THE WHOLE SERIALIZATION QUESTION ─────────────────────────────
 *
 * The plan opened Phase 3 expecting a fight here: `agent_store.live` returns a LIVE SDK Agent, and
 * behaviour does not cross a process boundary, so the one verb `spawn` depended on could not be
 * forwarded however open the door was. Three measurements dissolved it.
 *
 * FIRST — the wire form is already served on the same channel. `agent_store.list` returns
 * `SerializedAgent[]`, because AgentService maps `serializeForWire()` over its registry. `live` is a
 * MAIN-SIDE CONVENIENCE, documented as returning the canonical object rather than a copy, and that
 * property is the very thing a process boundary destroys. So the right move was never to find a way
 * to forward `live`; it was to notice that an out-of-process caller wants `list`, and that nothing had
 * to be added for it to.
 *
 * SECOND — this is what the RENDERER already does, which makes it the established route rather than a
 * new one. `renderer/src/agents/Agents.ts` hydrates wire JSON into a real Agent through exactly this
 * call, and the composer then reads its tool names off that rehydrated copy. This package is out of
 * process for the same reasons the renderer is, so it takes the same road. That is a STRONGER
 * thin-caller claim than the in-process version could make: reaching for `live` was a shortcut the
 * composer itself cannot take, so the old surface was subtly not on the road it claimed to be on.
 *
 * THIRD — the one method that would have needed more than the wire form turns out to be dead. See
 * `_fire`.
 *
 * EXACT NAME MATCHING, never fuzzy: a test that silently ran as the wrong agent is the same class of
 * defect this entire surface exists to stop.
 */
async function resolveAgent( ref: string, tool: string ): Promise<{ agent: Agent } | { refusal: ToolResult }> {
	const got = await verb( 'agent_store.list', tool );
	if ( 'refusal' in got ) return got;

	const rows  = ( got.value ?? [] ) as SerializedAgent[];
	const match = rows.find( ( a ) => a.id === ref ) ?? rows.find( ( a ) => a.name === ref );
	if ( !match ) {
		const names = rows.map( ( a ) => `${ a.name } ( ${ a.id } )` ).join( ', ' ) || 'none — the app holds no agents';
		return { refusal: fail( `${ tool }: no agent matches "${ ref }". Matching is by id or EXACT name, deliberately. Available: ${ names }` ) };
	}
	const agent = Agent.fromSerialized( match );

	// ── THE WIRE FORM IS NOT THE WHOLE AGENT, AND ONE FIELD DOWNSTREAM PROVES IT ──
	// `toolDefs` rides `bindEnv`, not `serializeForWire`, so a freshly rehydrated agent has none — and
	// `suggestedToolNames()` reads the DEFS rather than the mode map, precisely so a mode left behind for
	// a tool no longer served cannot name a tool that is not there. Without this bind the turn goes out
	// with an EMPTY tool surface for an agent that declares a full one, and nothing anywhere errors.
	//
	// THE RENDERER DOES EXACTLY THIS, which keeps the thin-caller rule intact: its agent store pulls
	// `mcp_store.tools` and flat-maps the servers into one list before binding. Same channel, same shape,
	// same one call — available out here only because the pull lane exists at all.
	//
	// A FAILED PULL REFUSES THE SPAWN rather than proceeding tool-less. The silent version of this cost a
	// green suite to notice; a run whose agent quietly lost its tools would report as a behaviour finding
	// about the agent, which is the most expensive wrong answer this surface can give.
	const defs = await Door.pull( 'mcp_store', 'tools' );
	if ( !isOk( defs ) ) return { refusal: refuse( defs, `${ tool } ( binding tool defs )` ) };
	agent.bindEnv( { toolDefs: ( ( defs.value ?? [] ) as { tools: ToolDef[] }[] ).flatMap( ( s ) => s.tools ?? [] ) } );

	return { agent };
}

/**
 * Emit the turn — the ONE place this file touches the wire, so the payload is built once.
 *
 * ── WHY `toolManifest` IS SENT EMPTY, WHICH IS NOT A SHORTCUT ───────────────────────────────────
 *
 * `chat_send` declares both `toolNames` and `toolManifest`, and only one of them is alive.
 *
 * `toolNames` is real and matters: CommunicationService feeds it to `_exposedTools`, which decides the
 * structured tool surface the turn actually carries. It comes from `suggestedToolNames()`, which reads
 * the agent's BOUND TOOL DEFS — so `resolveAgent` binds them off `mcp_store.tools` before the agent
 * gets here, the same way the renderer's store does. This file once claimed a rehydrated agent computed
 * the value correctly with nothing bound. That was true of an older implementation and stopped being
 * true without anything here changing; the suite caught it, which is the whole argument for the suite.
 *
 * `toolManifest` is DEAD ON THE WIRE. The Orchestrator states it outright: `input.toolManifest` is
 * deliberately not read any more, because the agent now builds the manifest from its own bound
 * `toolDefs` at turn open. The renderer still computes and ships a string that nothing consumes.
 *
 * THIS MATTERS BEYOND ONE FIELD, and it is why the reasoning is recorded rather than the value just
 * being passed. `toolDefs` is bound by `bindEnv` and is NOT part of the wire form, so `toolManifest()`
 * on a rehydrated agent would return an empty string anyway — and reproducing it properly would have
 * meant re-implementing the renderer's binder out here, which is precisely the second implementation
 * the thin-caller rule forbids. Had the field been live, this tool could not have been written this
 * way. It is dead, so the constraint never binds. Sending '' is therefore honest rather than lossy:
 * it is what the receiver ignores, and pretending to compute it would suggest a fidelity this side
 * does not have.
 *
 * ( The in-process version read the manifest off the canonical main-side Agent, which was subtly
 *   wrong in its own way: `toolDefs` is bound per turn by the Orchestrator, so a dev-spawned turn sent
 *   an empty manifest for an agent that had never run and a stale one for an agent that had. Nothing
 *   consumed it, so nothing broke — a dead field absorbing a real defect. )
 *
 * The two thinking dials take the composer's own defaults. A test that needs others wants them as
 * arguments; a field with one possible value is speculative until then.
 */
async function fire( agent: Agent, sessionId: string, text: string, tool: string ): Promise<{ traceId: string } | { refusal: ToolResult }> {
	const traceId = randomUUID();
	const reply   = await Door.emit( 'chat_send', {
		traceId,
		agentId:        agent.id,
		sessionId,
		text,
		toolNames:      agent.suggestedToolNames(),
		toolManifest:   '',
		thinkingEffort: 'medium',
		thinkingMode:   'chain'
	} );
	if ( reply.outcome !== 'accepted' ) return { refusal: refuse( reply, tool ) };
	return { traceId };
}

export function hotTools(): ToolDefinition[] {
	return [

		{
			name:        'dev_status',
			annotations: { readOnlyHint: true },
			description: 'Is Starmind actually up — router port, whether the renderer dev server answers, and what each window currently holds. Call this first; it is the only tool whose success proves the app is running.',
			doc:
				'THE ORIENTATION CALL FOR THE HOT HALF, and its role grew when this server moved out of the app. ' +
				'It used to be the check to run after a restart. It is now the check to run BEFORE anything, ' +
				'because a standalone server answers whether or not Starmind exists — a reply from any other ' +
				'tool no longer proves the app came back, or was ever there.\n\n' +
				'`renderer.reachable` is a real fetch against the dev server rather than a socket probe, because ' +
				'a listening port and a document that loads are different facts. `packaged: true` means there is ' +
				'no dev server by design and the field is not a failure.\n\n' +
				'`windows` is each window\'s own account — its current url and whether it is still loading. Read ' +
				'it BESIDE `renderer`: the case worth catching is a window holding the right address having ' +
				'failed to load anything from it. Main and the renderer fail independently, and the half that ' +
				'reports on itself is the half that still works.\n\n' +
				'`router.port` is the port actually bound, not the one requested — a taken fixed port falls back ' +
				'to ephemeral on purpose, and that fallback is exactly what a person is diagnosing when they ' +
				'ask. `supervised` says whether a restart rebuilds the whole dev session or only relaunches main.',
			inputSchema: { type: 'object', properties: {}, required: [] },
			handler:     async () => {
				const reply = await Door.status();
				if ( !isOk( reply ) ) return refuse( reply, 'dev_status' );
				return ok( { reachedApp: true, door: Door.url, ...( reply.value as Record<string, unknown> ) } );
			}
		},

		{
			name:        'list_verbs',
			annotations: { readOnlyHint: true },
			description: 'Enumerate what the door can reach: bus channels currently SERVED, IPC commands DECLARED, and the pull lane with its reads and writes. Three lists, deliberately not merged.',
			doc:
				'WHAT THE APP\'S INTERNAL API SURFACE ACTUALLY IS, which nothing else states in one place. An ' +
				'agent cannot call a verb it cannot name, and the eleven verbs this surface depends on were ' +
				'originally found by grepping a source file — which neither scales nor survives a rename.\n\n' +
				'`served` now carries each channel WITH THE OPS IT DECLARES. `ops: null` is not an empty list — it ' +
				'means that channel routes a parametric op space and cannot name them, which is a different ' +
				'fact from accepting nothing. The list is PARTIAL by construction and says so rather than ' +
				'claiming a completeness it does not have.\n\n' +
				'TWO LISTS BECAUSE THE DELTA IS THE FINDING. `served` is read off the live dispatch map, so a ' +
				'service that failed to arm is absent rather than assumed. `commands` is read off the declared ' +
				'vocabulary, which is a static fact about the source. A channel that something CALLS and nothing ' +
				'SERVES is exactly the wiring bug that once let a tool go green against a channel which did not ' +
				'exist; merging the lists would hide it.\n\n' +
				'Both are read from the app\'s OWN registries. This server keeps no mirror of them — a dev ' +
				'surface holding its own list is a dev surface that is quietly wrong about the app three weeks ' +
				'later, and registering a path the ordinary way is meant to be the only registration anyone ' +
				'performs.\n\n' +
				'`pulls` is the THIRD list and the one that matters most for coverage: it is where every service ' +
				'serving no bus channel lives. `armed: false` means declared but not serving in this run, which is a ' +
				'different fact from not being declared at all. `reads` are callable through `read_state` and `writes` ' +
				'through `write_state`; both are listed because the SPLIT is the finding — which lane an op sits on ' +
				'decides which tool reaches it, and the two halves are not the same size.',
			inputSchema: { type: 'object', properties: {}, required: [] },
			handler:     async () => {
				const reply = await Door.verbs();
				if ( !isOk( reply ) ) return refuse( reply, 'list_verbs' );
				return ok( reply.value );
			}
		},

		{
			name:        'read_state',
			annotations: { readOnlyHint: true },
			description: 'Read any declared pull-channel op — the lane that reaches the 14 services which serve no bus verb at all. Reads only.',
			doc:
				'THE OTHER HALF OF THE APP. `/dev/verb` reaches the bus, which 11 services serve. The remaining 14 ' +
				'declare no bus channel and are reachable only here — `kcd_store`, `project_store`, `harness`, ' +
				'`exec_store`, `constellation`, `debug_screenshot_store` and the rest. Call `list_verbs` for the ' +
				'declared channels and their ops.\n\n' +
				'NOTHING WAS ADDED TO ANY SERVICE FOR THIS. The pull registry and the gate that validates against ' +
				'it already existed for the renderer; this speaks the same envelope through the same entry point. A ' +
				'service becomes reachable by declaring a channel the ordinary way — there is no second table.\n\n' +
				'READS ONLY — A LANE, NOT A LIMIT. Every channel declares a reads/writes split; `write_state` serves ' +
				'the other half. This tool simply never asks for one, so a write op reached through it comes back ' +
				'`write-refused` instead of being performed. That is the point of the split: a tool whose NAME says it ' +
				'reads cannot mutate the app because someone mistyped an op.\n\n' +
				'FOUR OUTCOMES THAT LOOK ALIKE AND ARE NOT: `unregistered` ( not declared — a fact about the ' +
				'source ), `unarmed` ( declared, but nothing serving it in this run — a fact about this boot ), ' +
				'`write-refused`, and a real value that happens to be null. The gate itself answers all four with a ' +
				'bare null; they are separated before dispatch so they survive the trip.',
			inputSchema: {
				type:       'object',
				properties: {
					channel: { type: 'string', description: 'The pull channel, e.g. "kcd_store" or "project_store".' },
					op:      { type: 'string', description: 'A declared READ op on that channel.' },
					args:    { type: 'object', description: 'Optional argument object, exactly as the renderer would send it.' }
				},
				required: [ 'channel', 'op' ]
			},
			handler: async ( args ) => {
				const channel = String( args[ 'channel' ] ?? '' );
				const op      = String( args[ 'op' ] ?? '' );
				if ( !channel || !op ) return fail( 'read_state needs a "channel" and an "op". Call list_verbs for the declared pull channels and their ops.' );

				const reply = await Door.pull( channel, op, args[ 'args' ] );
				if ( !isOk( reply ) ) return refuse( reply, 'read_state' );
				// `undefinedValue` rides back rather than being flattened: a channel that answered with nothing
				// and a channel that answered null are two facts, and this is the seam where they would collapse.
				return ok( { channel, op, value: reply.value, undefinedValue: reply.undefinedValue } );
			}
		},

		{
			name:        'write_state',
			description: 'Perform any declared pull-channel WRITE — the ARRANGE half. Same lane and same gate as read_state; this one opts in to mutation.',
			doc:
				'THE ARRANGE HALF, and the half the rig lacked longest. `read_state` lets a run ASSERT; without this it ' +
				'could not SET UP, which leaves every check inheriting whatever state the app happened to be in. ' +
				'`Channels` declares 121 writes against 96 reads, so the mutating vocabulary is the LARGER half of the ' +
				'lane. Call `list_verbs` for the declared writes per channel.\n\n' +
				'THIS IS A REAL WRITE AGAINST A REAL APP. It goes through `PullGate.dispatch` — the same entry the ' +
				'renderer\'s IPC handler calls — so the gate plugs and the registry check run exactly as they do in ' +
				'life. There is no sandbox, no dry run and no undo. Project creation, vault saves, credential rows and ' +
				'process control are all in reach. Read the op before calling it.\n\n' +
				'NOT GOVERNED, AND KNOWINGLY SO. The pull lane stamps a `readonly` principal that NONE of its 25 ' +
				'handlers forward — for the renderer exactly as much as for this door — so nothing below here checks ' +
				'who is asking. What stands in for a gate is the TRACE: every call lands as `dev_door.write` on the ' +
				'capability channel, separate from the `dev_door.pull` a read leaves, so what a run CHANGED stays ' +
				'legible apart from what it merely looked at.\n\n' +
				'THE SAME FOUR OUTCOMES AS A READ: `unregistered` ( not declared — a fact about the source ), ' +
				'`unarmed` ( declared, but nothing serving it in this run — a fact about this boot ), a thrown ' +
				'handler, and a real value. Passing a READ op here is allowed and does nothing surprising: the door ' +
				'cares that a write was ASKED FOR, not that one was required.',
			inputSchema: {
				type:       'object',
				properties: {
					channel: { type: 'string', description: 'The pull channel, e.g. "project_store" or "kcd_store".' },
					op:      { type: 'string', description: 'A declared WRITE op on that channel.' },
					args:    { type: 'object', description: 'Optional argument object, exactly as the renderer would send it.' }
				},
				required: [ 'channel', 'op' ]
			},
			handler: async ( args ) => {
				const channel = String( args[ 'channel' ] ?? '' );
				const op      = String( args[ 'op' ] ?? '' );
				if ( !channel || !op ) return fail( 'write_state needs a "channel" and an "op". Call list_verbs for the declared pull channels and their writes.' );

				const reply = await Door.write( channel, op, args[ 'args' ] );
				if ( !isOk( reply ) ) return refuse( reply, 'write_state' );
				return ok( { channel, op, value: reply.value, undefinedValue: reply.undefinedValue } );
			}
		},

		{
			name:        'list_sessions',
			annotations: { readOnlyHint: true },
			description: 'List live sessions and the agents available to spawn. Read this before spawning if you do not already hold an agent id.',
			doc:
				'Returns `sessions` ( id, title, agent, status, turn count ) and `agents` ( id, name ), which is ' +
				'everything the other tools need as input.\n\n' +
				'Live registry state, not history — a session that ended is not here.',
			inputSchema: { type: 'object', properties: {}, required: [] },
			handler:     async () => {
				const gotSessions = await verb( 'session_store.list', 'list_sessions' );
				if ( 'refusal' in gotSessions ) return gotSessions.refusal;
				const gotAgents = await verb( 'agent_store.list', 'list_sessions' );
				if ( 'refusal' in gotAgents ) return gotAgents.refusal;

				const sessions = ( gotSessions.value ?? [] ) as SessionRef[];
				const agents   = ( gotAgents.value ?? [] ) as SerializedAgent[];
				const byId     = new Map( agents.map( ( a ) => [ a.id, a.name ] ) );

				return ok( {
					sessions: sessions.map( ( s ) => ( {
						sessionId: s.id,
						title:     s.title ?? null,
						agentId:   s.agentId,
						agentName: byId.get( s.agentId ) ?? '( no live agent )',
						status:    s.status ?? 'unknown',
						// NULL WHEN THE ROW DID NOT CARRY ONE, never 0. `session_store.list` does not return a
						// count today, and reporting every session — including ones with real history — as
						// having no turns is a number a test branches on and is quietly wrong about. Null is
						// unmistakably "not answered here", and it sends a reader to `get_turns`, which asks
						// the authority that actually knows.
						turns:     s.turnCount ?? null
					} ) ),
					agents: agents.map( ( a ) => ( { id: a.id, name: a.name } ) )
				} );
			}
		},

		{
			name:        'spawn_agent',
			description: 'Create a real Starmind session on an existing agent and send it a first turn. Returns immediately with the session id — the turn runs in the background.',
			doc:
				'Starts a REAL session, not a simulation: the same sequence the composer performs when a person ' +
				'presses Send, so what it exercises is what ships.\n\n' +
				'`agent` accepts an agent id or its EXACT name. `prompt` is the first turn.\n\n' +
				'FIRE AND FORGET. The call returns as soon as the turn is accepted, carrying `sessionId` and ' +
				'`traceId`. A turn takes 30-90 seconds; there is no polling tool and no completion event here on ' +
				'purpose. Wait, then read `get_turns` or the trace files ( `frontier.turn_usage` on that session ' +
				'marks the end of a harness turn ). The `traceId` is how a call\'s own lines are found among ' +
				'several agents running at once.\n\n' +
				'THREE ROUND TRIPS, and deliberately not folded into one app-side helper: resolve the agent, ' +
				'create the session, fire the turn — the same three steps the composer takes, each through the ' +
				'verb the product already uses. Batching them would put a second implementation of the composer ' +
				'inside the rig meant to test it.\n\n' +
				'Use `list_sessions` first if you do not know which agents exist.',
			inputSchema: {
				type:       'object',
				properties: {
					agent:  { type: 'string', description: 'Agent id, or the agent\'s exact name.' },
					prompt: { type: 'string', description: 'The first turn to send.' }
				},
				required: [ 'agent', 'prompt' ]
			},
			handler: async ( args ) => {
				const ref    = String( args[ 'agent' ] ?? '' );
				const prompt = String( args[ 'prompt' ] ?? '' );
				if ( !ref )    return fail( 'spawn_agent needs an "agent" — an agent id or exact name. Call list_sessions to see them.' );
				if ( !prompt ) return fail( 'spawn_agent needs a "prompt" — the first turn to send.' );

				const resolved = await resolveAgent( ref, 'spawn_agent' );
				if ( 'refusal' in resolved ) return resolved.refusal;
				const agent = resolved.agent;

				// `create` returns the row, so the id comes from the authority rather than being minted here
				// and hoped about. POSITIONAL, like every bus verb — the object form is the renderer's pull
				// channel, a different door onto the same method.
				const made = await verb( 'session_store.create', 'spawn_agent', agent.id, `dev: ${ prompt.slice( 0, 40 ) }` );
				if ( 'refusal' in made ) return made.refusal;
				const session = made.value as SessionRef | null;
				if ( !session ) return fail( `spawn_agent: created no session for agent "${ agent.name }" — the session store refused it. The verb was reached and answered; this is a fact about the app, not the connection.` );

				const fired = await fire( agent, session.id, prompt, 'spawn_agent' );
				if ( 'refusal' in fired ) return fired.refusal;

				return ok( { sessionId: session.id, traceId: fired.traceId, agentId: agent.id, agentName: agent.name, accepted: true } );
			}
		},

		{
			name:        'send_to_agent',
			description: 'Send another turn to a session that already exists. Returns immediately — the turn runs in the background.',
			doc:
				'The follow-up half of `spawn_agent`, and the same fire-and-forget contract: accepted, not ' +
				'finished.\n\n' +
				'The session must already exist ( `list_sessions` ). Its agent, project and grants are whatever ' +
				'that session already holds — this adds a turn and changes nothing else about it.\n\n' +
				'THE AGENT COMES OFF THE SESSION, never off the caller. A turn belongs to whichever agent the ' +
				'session was assigned; letting a caller name one would allow two turns in one conversation to ' +
				'run as different agents, which is a state the rest of the system has no way to represent.',
			inputSchema: {
				type:       'object',
				properties: {
					sessionId: { type: 'string', description: 'The session to send to.' },
					message:   { type: 'string', description: 'The turn text.' }
				},
				required: [ 'sessionId', 'message' ]
			},
			handler: async ( args ) => {
				const sessionId = String( args[ 'sessionId' ] ?? '' );
				const message   = String( args[ 'message' ] ?? '' );
				if ( !sessionId ) return fail( 'send_to_agent needs a "sessionId". Call list_sessions to see them.' );
				if ( !message )   return fail( 'send_to_agent needs a "message".' );

				const got = await verb( 'session_store.get', 'send_to_agent', sessionId );
				if ( 'refusal' in got ) return got.refusal;
				const session = got.value as SessionRef | null;
				if ( !session ) return fail( `send_to_agent: no live session "${ sessionId }". The app answered — the session does not exist. Call list_sessions.` );

				const resolved = await resolveAgent( session.agentId, 'send_to_agent' );
				if ( 'refusal' in resolved ) return resolved.refusal;
				const agent = resolved.agent;

				const fired = await fire( agent, sessionId, message, 'send_to_agent' );
				if ( 'refusal' in fired ) return fired.refusal;

				return ok( { sessionId, traceId: fired.traceId, agentId: agent.id, agentName: agent.name, accepted: true } );
			}
		},

		{
			name:        'get_turns',
			annotations: { readOnlyHint: true },
			description: 'Read the turns of one session — what was actually said, and what the agent actually did.',
			doc:
				'The other half of the fire-and-forget contract: `spawn_agent` returns the moment a turn is ' +
				'accepted, and this is how the outcome is read back once it has run.\n\n' +
				'Pairs with the traces rather than replacing them. This says what the CONVERSATION holds; ' +
				'`trace-capability.jsonl` says what crossed the gate. A capability claim wants both — a turn ' +
				'reporting a refusal in prose and a `gate.verdict` line agreeing with it are two independent ' +
				'witnesses.',
			inputSchema: {
				type:       'object',
				properties: { sessionId: { type: 'string', description: 'The session whose turns to read.' } },
				required:   [ 'sessionId' ]
			},
			handler: async ( args ) => {
				const sessionId = String( args[ 'sessionId' ] ?? '' );
				if ( !sessionId ) return fail( 'get_turns needs a "sessionId". Call list_sessions to see them.' );

				// POSITIONAL. The `{ sessionId }` object form is the renderer's pull channel — a different door
				// onto the same loader — and passing it here would stringify to "[object Object]" and load nothing.
				const got = await verb( 'communication.turns', 'get_turns', sessionId );
				if ( 'refusal' in got ) return got.refusal;

				// ABSENCE IS NOT FAILURE, and the two must not share a value. A session with no turns yet is a
				// legitimate answer and comes back as an empty list; a session that does not exist is a
				// different fact and says so, because a caller reading one for the other either waits forever
				// for a turn that was never accepted or concludes a real session is empty.
				const turns = got.value as unknown[] | null;
				if ( !turns ) return fail( `get_turns: no turns for "${ sessionId }" — the session does not exist, or the conversation was never created. The app answered; this is not a connection problem. Call list_sessions.` );
				return ok( { sessionId, count: turns.length, turns } );
			}
		},

		{
			name:        'list_decisions',
			annotations: { readOnlyHint: true },
			description: 'List the decisions currently posed to a person and not yet settled — what is blocking, and who is asking.',
			doc:
				'THE INSTRUMENT FOR AN `ask` POLICY. A gate at `ask` suspends its call on a person\'s answer, so ' +
				'an unattended run of one does not fail — it hangs, silently, until a timeout that mostly is not ' +
				'set. This is how that state becomes visible instead of looking like a slow turn.\n\n' +
				'READ-ONLY ON PURPOSE. Nothing here settles a decision: a person does that, and the authority ' +
				'keeps one exit so that stays true. If this lists something, the run needs a human.\n\n' +
				'Each row carries `agentName` and `agentId` — WHO is asking, which is the key to read when ' +
				'several agents are running. `traceId` says WHICH TURN, and is answerable only by the in-process ' +
				'lane: a routed harness call reaches the gate over HTTP with no per-turn trace, so an empty one ' +
				'there is a fact about the lane rather than a missing value.',
			inputSchema: { type: 'object', properties: {}, required: [] },
			handler: async () => {
				const got = await verb( 'decisions.list', 'list_decisions' );
				if ( 'refusal' in got ) return got.refusal;
				const open = ( got.value ?? [] ) as unknown[];
				// The count is stated rather than left to be derived, because ZERO is the answer this tool
				// exists to deliver clearly: "nothing is blocking" is what an unattended run needs to assert,
				// and a bare empty array is easy to read as a call that did not work.
				return ok( { open: open.length, decisions: open } );
			}
		},

		{
			name:        'get_policies',
			annotations: { readOnlyHint: true },
			description: 'Read every permission gate, what it permits FOR ONE RUN, its secure default, and which tools declare it. Includes the global master stop.',
			doc:
				'The deck\'s own snapshot, through the same expression the deck reads. Call it before AND after ' +
				'`set_policy` — an assertion that a policy CHANGED is worth more than one that it was set, ' +
				'because the second only proves the call returned.\n\n' +
				'`tools` names what each row actually governs ( `server · tool` ). An EMPTY list is information ' +
				'rather than a gap: the row is live and currently governs nothing declared — which is also what ' +
				'a row under-reports while a TRANSITIONAL matcher is doing its selecting.',
			inputSchema: {
				type:       'object',
				properties: {
					sessionId: { type: 'string', description: 'WHICH RUN to read. Omit for the secure defaults — what a run holding no remembered answers gets.' }
				},
				required: []
			},
			handler: async ( args ) => {
				const sessionId = String( args[ 'sessionId' ] ?? '' );
				const got = await verb( 'permissions.rows', 'get_policies', { sessionId: sessionId || null } );
				if ( 'refusal' in got ) return got.refusal;
				if ( !got.value ) return fail( 'get_policies: `permissions.rows` was reached and returned nothing. That is a wiring fault in the app, not a policy state and not a connection problem.' );
				return ok( got.value );
			}
		},

		{
			name:        'set_policy',
			description: 'Set one permission gate to allow / ask / off FOR ONE RUN, or engage the global master stop. Returns that run\'s resulting rows.',
			doc:
				'The write that makes the deck testable. A row sitting at its secure default cannot be exercised ' +
				'without either changing it or finding a person.\n\n' +
				'`gateId` is a registered row ( `get_policies` lists them ); `policy` is `allow`, `ask` or `off`.\n\n' +
				'DO NOT SET A ROW TO `ask` IN AN UNATTENDED RUN. The call it governs will suspend on a human ' +
				'answer that is not coming, and the turn hangs rather than failing — `list_decisions` is how ' +
				'that is DETECTED, not how it is prevented. `allow` and `off` are the two settled ends and are ' +
				'what an autonomous test should use.\n\n' +
				'Pass `stopAll` instead of a gate to engage or lift the master stop, which refuses every tool ' +
				'call regardless of any row and is the one refusal offering no way around itself.\n\n' +
				'RUN-SCOPED, AND THAT IS LOAD-BEARING. A remembered policy lives on the passport of the run that ' +
				'answered it, so setting a row for one session changes nothing for the others running beside it. ' +
				'Pass the `sessionId` of the run you are testing — a session that has not sent a turn yet holds ' +
				'no passport and cannot be stamped.\n\n' +
				'THE MASTER STOP IS THE EXCEPTION and takes no session: it is global by ruling, because a person ' +
				'hitting stop means everything, now.\n\n' +
				'THE OLD LOCKOUT IS GONE. When this surface was a tenant of the app it was itself matched by the ' +
				'`third_party_tools` row, so setting that row to `off` refused `set_policy` and `restart_app` ' +
				'together and the only capability that could lift it was the first thing it took away. This ' +
				'server sits outside the gate by ruling, so a policy write can no longer disable the instrument ' +
				'that performs it.',
			inputSchema: {
				type:       'object',
				properties: {
					sessionId: { type: 'string', description: 'WHICH RUN remembers this. Required unless using stopAll — a policy is stamped on the run that answered it, never globally.' },
					gateId:    { type: 'string', description: 'The gate to set — omit when using stopAll.' },
					policy:    { type: 'string', enum: [ 'allow', 'ask', 'off' ], description: 'The policy to write.' },
					stopAll:   { type: 'boolean', description: 'Engage ( true ) or lift ( false ) the master stop instead of setting a row.' }
				},
				required: []
			},
			handler: async ( args ) => {
				const sessionId = String( args[ 'sessionId' ] ?? '' );
				const gateId    = String( args[ 'gateId' ] ?? '' );
				const policy    = String( args[ 'policy' ] ?? '' );
				const stopAll   = args[ 'stopAll' ] as boolean | undefined;

				// THE SNAPSHOT RIDES BACK so that "it was set" and "it is now this" are one call and cannot
				// disagree. A test asserting on the return value is then asserting on the authority's own
				// state rather than on this tool's report of having asked.
				//
				// WHAT WAS ASKED LIVES UNDER `requested`, AND THE FIRST VERSION OF THIS DID NOT. It spread
				// the arguments flat beside the snapshot, and for `stopAll` the two collided on one key —
				// the requested value written first, the authority's value overwriting it. The reply then
				// answered "did it work?" with a field that silently meant something else, which is this
				// project's signature defect authored into the tool built to catch it. Caught by the first
				// test run of the ported suite, which is the argument for porting it before the deletion
				// rather than after.
				//
				// The rule is now structural rather than remembered: `requested` is what the caller asked
				// for, everything at the top level is the authority's own state, and no future field can
				// collide with a snapshot key by accident.
				const snapshot = async (): Promise<Record<string, unknown>> => {
					const got = await verb( 'permissions.rows', 'set_policy', { sessionId: sessionId || null } );
					return 'refusal' in got ? {} : ( got.value ?? {} ) as Record<string, unknown>;
				};

				// The master stop is a FIELD BESIDE the table, not a row in it, so it is a different call
				// rather than a policy value — folding it in would make lifting it destroy the state it has
				// to put back.
				if ( stopAll !== undefined ) {
					const got = await verb( 'permissions.stopAll', 'set_policy', { on: stopAll } );
					if ( 'refusal' in got ) return got.refusal;
					return ok( { requested: { stopAll }, ...await snapshot() } );
				}

				if ( !gateId ) return fail( 'set_policy needs a "gateId", or a "stopAll" boolean. Call get_policies for the registered rows.' );
				// A POLICY BELONGS TO A RUN. There is no scope meaning "loosen this for everybody" — that
				// scope was the leak this whole surface was rebuilt to close — so a write with no session has
				// nowhere to land and says so, rather than appearing to succeed against nothing.
				if ( !sessionId ) return fail( 'set_policy needs a "sessionId" — a policy is remembered on the RUN that answered it, not globally. Use spawn_agent or list_sessions to get one. ( "stopAll" is the exception: the master stop is global and takes no session. )' );
				if ( policy !== 'allow' && policy !== 'ask' && policy !== 'off' ) {
					return fail( `set_policy needs "policy" to be allow, ask or off — got "${ policy }".` );
				}

				const got = await verb( 'permissions.set', 'set_policy', { sessionId, id: gateId, policy } );
				if ( 'refusal' in got ) return got.refusal;
				// A FALSE HERE IS AN UNKNOWN GATE **OR** A RUN WITH NO PASSPORT, and the two are worth telling
				// apart in the message: a session that has never sent holds no document to stamp, which reads
				// identically to a typo unless the failure says so.
				if ( !got.value ) return fail( `set_policy: could not set "${ gateId }" on session "${ sessionId }" — either no such gate ( call get_policies ) or that run has not sent a turn yet, so it holds no passport to stamp. The app answered; this is not a connection problem.` );

				return ok( { requested: { gateId, policy, sessionId }, ...await snapshot() } );
			}
		},

		{
			name:        'restart_app',
			description: 'Relaunch Starmind. Returns immediately; the process dies a moment later and comes back up. Call dev_status afterwards to confirm it did.',
			doc:
				'WHY IT EXISTS: main-process code does not hot-reload, so every change to a service, a gate or a ' +
				'tool table is inert until the app restarts. Without this an autonomous run stops at its first ' +
				'edit and waits for a person, which is the loop this surface exists to break.\n\n' +
				'THIS TOOL GAINED THE MOST FROM MOVING OUT OF THE APP. It used to kill the server that was ' +
				'serving the call, so nothing could observe the outcome — the caller had to leave and come back. ' +
				'This server survives the app it restarts, so `restart_app` then `dev_status` is a sequence that ' +
				'can be written down and asserted on. THAT is the loop an unattended run needs: apply a ' +
				'main-process change, restart, CONFIRM it came back, continue. Do not skip the confirm — a reply ' +
				'here only means the quit was scheduled.\n\n' +
				'EVERYTHING IN MEMORY IS LOST, which is mostly the point: session policy overrides, the master ' +
				'stop and every open decision return to their secure defaults. Live sessions do not survive, so ' +
				're-spawn afterwards and never hold a session id across it.\n\n' +
				'THE RENDERER NEEDS A SUPERVISOR. Under `npm run dev:proxied` the dev session is rebuilt whole ' +
				'and the window returns. Started any other way, this relaunches Electron directly — main comes ' +
				'back and answers, but quitting the app also ends the renderer dev server, so the window is ' +
				'WHITE afterwards. Anything that has to be seen or clicked, a decision prompt above all, is ' +
				'unavailable until a person restarts the dev session. `dev_status` reports `supervised` so this ' +
				'is knowable BEFORE the call rather than discovered after it.\n\n' +
				'Allow a few seconds before the first call afterwards — the endpoint arms early in boot, but not ' +
				'instantly.',
			inputSchema: { type: 'object', properties: {}, required: [] },
			handler: async () => {
				const reply = await Door.restart();
				if ( !isOk( reply ) ) return refuse( reply, 'restart_app' );
				return ok( { ...( reply.value as Record<string, unknown> ), confirmWith: 'dev_status — a reply here means the quit was scheduled, nothing more.' } );
			}
		}

	];
}
