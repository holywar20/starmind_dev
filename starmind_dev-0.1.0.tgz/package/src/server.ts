import { McpServer } from './mcp';
import type { ToolDefinition } from './mcp';
import { Workspace } from './Workspace';
import { coldTools } from './tools/cold';
import { hotTools } from './tools/hot';

/**
 * StarmindDevServer — the internal testing surface, as a server that owns its own process.
 *
 * ── WHAT CHANGED, AND WHY IT MATTERS ────────────────────────────────────────────────────────────
 *
 * This surface used to be a tenant of the running application: an in-process tool table armed by
 * Starmind's MCPService and reached over the app's own loopback router. That shape had one defect
 * that no amount of tidying fixes — it could not exist without the thing it exists to test. Every
 * tool on it, including the ones that only read, was unavailable whenever Starmind was down, which
 * is precisely when a cold suite, a CI run, or a first-boot check would want them.
 *
 * So the dependency is inverted. This is a server, modelled on daedalus, that reaches INTO the
 * application when the application happens to be running, and does useful work when it is not.
 *
 * ── TWO CLASSES OF TOOL ─────────────────────────────────────────────────────────────────────────
 *
 *   COLD  needs no application. Runs suites, takes the census, reads the tree.
 *   HOT   needs the application. Spawns agents, reads policies, injects declared IPC crossings.
 *
 * The split is the architecture rather than a labelling exercise, and it was built in that order on
 * purpose: the cold tools depend on nothing in the attach seam, so they proved the package genuinely
 * stands up alone before anything was built that assumed it does.
 *
 * BOTH HALVES NOW EXIST, and the seam between them is a REPLY, not an exception. A hot tool that
 * cannot reach the app answers with a named outcome saying so and stating that nothing was tested —
 * see `Door`. The alternative, a server that fails to start or hides its hot tools when Starmind is
 * down, would take the tools away at exactly the moment someone is diagnosing why it is down.
 *
 * ── NOT GOVERNED, AND NOT SHIPPED ───────────────────────────────────────────────────────────────
 *
 * Ruled 2026-08-23. This server sits OUTSIDE Starmind's gate and permission middleware rather than
 * declaring rows into it. Governing the instrument by the system it measures is a circular
 * dependency, not a safety property: the previous arrangement produced a live lockout in which
 * turning one permission row off refused `set_policy` and `restart_app` together, so the only
 * capability that could lift it was the first thing it removed. A test rig a misconfigured policy
 * can disable is a test rig that vanishes exactly when it is needed.
 *
 * What replaces governance is ACCOUNTABILITY. Once the hot half lands, every call this server makes
 * into the app is traced — verb, caller, outcome — because with no gate in the path the trace stops
 * being the best account of what it did and becomes the only one.
 *
 * It also never ships, and that is structural rather than a promise: this package exports no
 * `ServerManifest`, and Starmind's `promote:mcp` discovers servers by finding one. There is nothing
 * here for the discovery pass to catch. See `./mcp/index.ts`.
 *
 * ── NO BASE CLASS ───────────────────────────────────────────────────────────────────────────────
 *
 * Same reasoning daedalus recorded: this project will only ever possess THIS ONE server, so an
 * abstract base would exist to serve a plurality it does not have. The wire stays its own module
 * because that genuinely is a separate concern.
 */
export class StarmindDevServer {

	private readonly mcp = new McpServer( { name: 'starmind_dev', version: '0.1.0' } );

	constructor() {
		for ( const tool of this.tools() ) this.mcp.registerTool( tool );
	}

	/**
	 * The full tool table. Cold first and, for now, cold only.
	 *
	 * The hot half APPENDS here rather than forking a second server — one process, one tool list, with
	 * the cold/hot distinction living in whether a tool needs the door. A caller should not have to know
	 * which of two servers to ask; it should ask, and be told plainly when the application is not
	 * running. Registered UNCONDITIONALLY, without probing for the app first: a table that changed shape
	 * depending on whether Starmind happened to be up would make an absent tool and an absent app the
	 * same observation, and the client only reads this list once anyway.
	 */
	private tools(): ToolDefinition[] {
		return [ ...coldTools(), ...hotTools() ];
	}

	/** Start serving on stdio. Resolves when the client disconnects. */
	async run(): Promise<void> {
		// Announced on stderr, never stdout — stdout is the JSON-RPC channel and one stray line on it
		// corrupts the stream for the whole session. The root is worth announcing because "which tree
		// am I describing" is the single question a wrong answer from a cold tool comes down to.
		const root = Workspace.find();
		process.stderr.write( `starmind_dev: serving. workspace root: ${ root ?? '( none found )' }\n` );
		await this.mcp.connect();
	}

	/** The wire tool surface, for a verify pass or an inspector — read without constructing a session. */
	surface(): Record<string, unknown>[] {
		return this.mcp.listTools();
	}
}
