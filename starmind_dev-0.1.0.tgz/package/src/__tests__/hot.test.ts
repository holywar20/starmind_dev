import { afterEach, beforeEach, describe, expect, it } from 'vitest';

import { hotTools } from '../tools/hot';
import { TestApp, agentRow } from './TestApp';

/**
 * The hot tools, driven through the REAL Door over a REAL socket into a scripted app.
 *
 * ── WHERE THESE CAME FROM ───────────────────────────────────────────────────────────────────────
 *
 * Most are ports of `starmind/src/main/__tests__/Dev.test.ts`, which covered the in-process tool
 * table that Phase 4 deletes. Porting them BEFORE the deletion was the point: the behaviours they
 * pin — an empty session versus a missing one, a null turn count versus zero, a policy stamp landing
 * on one run and not another — are properties of the TOOLS, and the tools did not stop existing when
 * they changed process. Deleting the table without moving these would have quietly traded ten
 * behavioural tests for nothing and left `test_census` reporting this package as having no suite.
 *
 * Two of the originals did NOT come across, and their absence is a ruling rather than an oversight.
 * They asserted that every tool declares a permission gate and that ungoverned is stated as
 * `gates: {}` rather than reached by silence. Both were true of a tenant living inside Starmind's
 * gate. This server sits outside it by ruling, declares no gates at all, and a test asserting it
 * declares them would now be asserting the opposite of the design.
 */
describe( 'the hot tools', () => {

	const tools = Object.fromEntries( hotTools().map( ( t ) => [ t.name, t ] ) );
	let app: TestApp;

	/** Read a tool's reply as JSON. Refusals are prose by design, so this is only for successes. */
	async function json( name: string, args: Record<string, unknown> = {} ): Promise<Record<string, unknown>> {
		const r = await tools[ name ]!.handler( args );
		expect( r.isError, `${ name } refused: ${ r.content[ 0 ]?.text }` ).not.toBe( true );
		return JSON.parse( r.content[ 0 ]!.text! ) as Record<string, unknown>;
	}

	/** Read a tool's refusal text. Asserts it IS a refusal — a tool that succeeded where a test
	 *  expected a refusal must not slip through as an empty string. */
	async function refusal( name: string, args: Record<string, unknown> = {} ): Promise<string> {
		const r = await tools[ name ]!.handler( args );
		expect( r.isError, `${ name } unexpectedly succeeded` ).toBe( true );
		return r.content[ 0 ]!.text!;
	}

	beforeEach( async () => {
		app = await new TestApp()
			.command( 'chat_send' )
			.verb( 'agent_store.list', () => [ agentRow( 'a1', 'Tester', { grep: 'suggested', write: 'on' } ) ] )
			.verb( 'session_store.list', () => [ { id: 's1', agentId: 'a1', title: 'One', status: 'active' } ] )
			.verb( 'session_store.get', ( id ) => ( id === 's1' ? { id: 's1', agentId: 'a1' } : null ) )
			.verb( 'session_store.create', ( agentId ) => ( { id: 's-new', agentId } ) )
			.verb( 'communication.turns', ( id ) => ( id === 's1' ? [] : null ) )
			.verb( 'decisions.list', () => [] )
			.verb( 'permissions.rows', () => ( { rows: [ { id: 'read', policy: 'allow' } ], stopAll: false } ) )
			// The tool catalogue the renderer's agent store binds off, and the reason `spawn_agent` can compute a
			// tool surface at all out here. `grep` is `suggested` on the fixture agent, `write` is `on`.
			.pull( 'mcp_store', { reads: [ 'tools' ], fn: () => [ { id: 'srv', tools: [
				{ name: 'grep',  description: 'g', inputSchema: {} },
				{ name: 'write', description: 'w', inputSchema: {} }
			] } ] } )
			.pull( 'kcd_store',     { reads: [ 'catalog', 'quiet' ], writes: [ 'save' ], fn: ( a ) => ( a ? { asked: a } : undefined ) } )
			.pull( 'project_store', { reads: [ 'list' ], writes: [ 'create' ], armed: false } )
			.listen();
	} );

	afterEach( async () => { await app.stop(); } );

	// ── The distinctions that must not collapse ──────────────────────────────────────────────

	it( 'tells an empty session apart from one that does not exist', async () => {
		// A session with no turns yet is a legitimate answer and must come back as an empty list. A
		// session that does not exist is a DIFFERENT fact. A caller that reads one for the other either
		// waits forever for a turn that was never accepted, or concludes a real session is empty.
		const empty = await json( 'get_turns', { sessionId: 's1' } );
		expect( empty[ 'count' ] ).toBe( 0 );

		const missing = await refusal( 'get_turns', { sessionId: 'nope' } );
		expect( missing ).toContain( 'does not exist' );
		// And it must say the app ANSWERED, so the reader does not go looking for a connection problem.
		expect( missing ).not.toContain( 'NOTHING WAS TESTED' );
	} );

	it( 'reports an unanswered turn count as null, never as zero', async () => {
		// `session_store.list` does not return a count. Zero is a number a test branches on and is
		// quietly wrong about; null is unmistakably "not answered here" and sends a reader to get_turns.
		const body = await json( 'list_sessions' );
		const rows = body[ 'sessions' ] as { turns: number | null }[];
		expect( rows[ 0 ]!.turns ).toBeNull();
	} );

	it( 'states an empty decision queue as a count rather than only an empty list', async () => {
		// ZERO is the answer this tool exists to deliver clearly — "nothing is blocking" is what an
		// unattended run needs to assert, and a bare empty array reads like a call that did not work.
		const body = await json( 'list_decisions' );
		expect( body[ 'open' ] ).toBe( 0 );
		expect( body[ 'decisions' ] ).toEqual( [] );
	} );

	// ── Spawning: the sequence, not just the result ──────────────────────────────────────────

	it( 'walks the composer\'s own four steps, in order', async () => {
		const body = await json( 'spawn_agent', { agent: 'a1', prompt: 'go' } );
		expect( body[ 'sessionId' ] ).toBe( 's-new' );
		expect( body[ 'accepted' ] ).toBe( true );

		// THE ORDER IS THE CLAIM. "It called them" is weaker than "it called them in the sequence the
		// composer performs", and the whole justification for this surface is that it takes the same road.
		//
		// FOUR STEPS, NOT THREE — the tool-def bind used to be invisible here, because a rehydrated agent
		// once computed its suggested surface off the mode map alone. It reads the DEFS now, so the bind is a
		// real step on the road and is asserted as one rather than left to be rediscovered by a live run.
		expect( app.asked.map( ( a ) => a.verb ) ).toEqual( [ 'agent_store.list', 'mcp_store.tools', 'session_store.create', 'chat_send' ] );
		expect( app.asked[ 3 ]!.mode ).toBe( 'emit' );
	} );

	it( 'returns the trace id the turn actually rides under', async () => {
		// A fire-and-forget call is only useful if its outcome can be found afterwards, and every
		// capability line the turn produces is keyed by this id.
		const body    = await json( 'spawn_agent', { agent: 'a1', prompt: 'go' } );
		const payload = app.asked.find( ( a ) => a.verb === 'chat_send' )!.args[ 0 ] as { traceId: string };
		expect( body[ 'traceId' ] ).toBe( payload.traceId );
		expect( String( body[ 'traceId' ] ) ).not.toHaveLength( 0 );
	} );

	it( 'resolves an agent by exact name as well as by id, and refuses a near miss', async () => {
		const byName = await json( 'spawn_agent', { agent: 'Tester', prompt: 'go' } );
		expect( byName[ 'agentId' ] ).toBe( 'a1' );

		// EXACT, never fuzzy: a test that silently ran as the wrong agent is the same class of defect
		// this entire surface exists to stop.
		const near = await refusal( 'spawn_agent', { agent: 'tester', prompt: 'go' } );
		expect( near ).toContain( 'no agent matches' );
	} );

	it( 'sends the tool names the agent injects, computed off the rehydrated agent', async () => {
		// THE HEART OF 3.a. `suggestedToolNames()` reads effectiveToolModes(), which rides the wire form
		// in full — so a rehydrated copy computes the same answer the composer does. If this ever breaks,
		// a dev-spawned turn silently runs with a different tool surface from a real one, which
		// invalidates every result taken through this surface.
		await json( 'spawn_agent', { agent: 'a1', prompt: 'go' } );
		const payload = app.asked.find( ( a ) => a.verb === 'chat_send' )!.args[ 0 ] as { toolNames: string[] };
		expect( payload.toolNames ).toEqual( [ 'grep' ] );        // `suggested`, not the `on` one
	} );

	it( 'takes the agent off the SESSION when sending, never off the caller', async () => {
		// A turn belongs to whichever agent the session was assigned. Letting a caller name one would
		// allow two turns in one conversation to run as different agents — a state nothing downstream
		// can represent.
		const body = await json( 'send_to_agent', { sessionId: 's1', message: 'more' } );
		expect( body[ 'agentId' ] ).toBe( 'a1' );
		expect( app.asked.map( ( a ) => a.verb ) ).toEqual( [ 'session_store.get', 'agent_store.list', 'mcp_store.tools', 'chat_send' ] );
	} );

	// ── Policy writes ────────────────────────────────────────────────────────────────────────

	it( 'refuses an unknown gate, a bad policy value, and a run with no passport — each differently', async () => {
		app.verb( 'permissions.set', () => false );

		expect( await refusal( 'set_policy', { sessionId: 's1' } ) ).toContain( 'needs a "gateId"' );
		expect( await refusal( 'set_policy', { gateId: 'read', policy: 'allow' } ) ).toContain( 'needs a "sessionId"' );
		expect( await refusal( 'set_policy', { sessionId: 's1', gateId: 'read', policy: 'maybe' } ) ).toContain( 'allow, ask or off' );

		// A false from the authority is an unknown gate OR a run holding no passport, and the message
		// says both — a session that has never sent reads identically to a typo unless it does.
		const refused = await refusal( 'set_policy', { sessionId: 's1', gateId: 'read', policy: 'allow' } );
		expect( refused ).toContain( 'no such gate' );
		expect( refused ).toContain( 'has not sent a turn yet' );
	} );

	it( 'carries the resulting rows back, so "it was set" and "it is now this" cannot disagree', async () => {
		app.verb( 'permissions.set', () => true );
		const body = await json( 'set_policy', { sessionId: 's1', gateId: 'read', policy: 'off' } );
		expect( body[ 'requested' ] ).toEqual( { gateId: 'read', policy: 'off', sessionId: 's1' } );
		// The snapshot is read from the authority AFTER the write, so a test asserting on this is
		// asserting on the app's own state rather than on the tool's report of having asked.
		expect( app.asked.filter( ( a ) => a.verb === 'permissions.rows' ) ).toHaveLength( 1 );
		expect( body[ 'rows' ] ).toBeDefined();
	} );

	it( 'engages the master stop as its own call, not as a policy value', async () => {
		// The stop is a FIELD BESIDE the table, not a row in it. Folding it in would make lifting it
		// destroy the state it has to put back.
		app.verb( 'permissions.stopAll', () => true );
		const body = await json( 'set_policy', { stopAll: true } );
		expect( app.asked.some( ( a ) => a.verb === 'permissions.set' ) ).toBe( false );

		// WHAT WAS ASKED AND WHAT IS NOW TRUE ARE TWO FACTS AND TWO KEYS. The first version of this tool
		// spread them onto one, so the authority's snapshot silently overwrote the requested value and the
		// reply answered a question nobody asked. Asserting on both is what makes the disagreement
		// between them visible — which is the whole reason the snapshot rides back at all.
		expect( body[ 'requested' ] ).toEqual( { stopAll: true } );
		expect( body[ 'stopAll' ] ).toBe( false );          // the scripted app has not moved
	} );

	// ── The pull lane: four answers that the gate itself gives as one ────────────────────────

	it( 'separates unregistered, unarmed, write-refused and a real null', async () => {
		// `PullGate.dispatch` answers ALL of these with a bare null — the same collapse `Bus.request`
		// had before `Bus.routes()`, one lane over. They are told apart BEFORE dispatch so they survive.
		expect( await refusal( 'read_state', { channel: 'kcd_store',     op: 'nope' } ) ).toContain( 'unregistered' );
		expect( await refusal( 'read_state', { channel: 'kcd_store',     op: 'save' } ) ).toContain( 'write-refused' );   // a LANE refusal
		expect( await refusal( 'read_state', { channel: 'project_store', op: 'list' } ) ).toContain( 'unarmed' );

		// And a read that legitimately has nothing to say is a SUCCESS carrying that fact, not a refusal.
		const nothing = await json( 'read_state', { channel: 'kcd_store', op: 'quiet' } );
		expect( nothing[ 'undefinedValue' ] ).toBe( true );
		expect( nothing[ 'value' ] ).toBeNull();
	} );

	it( 'serves a write through write_state and refuses the same op through read_state', async () => {
		// THE REFUSAL IS LANE-SHAPED, NOT CAPABILITY-SHAPED, and this is the test that says so out loud. It
		// was capability-shaped once and that was never a guarantee: `room_store` serves its writes on the
		// BUS, so the identical op was reachable through `/dev/verb` the whole time it was refused here.
		// What survives is the part that IS worth keeping — a tool whose name says it reads cannot mutate.
		expect( await refusal( 'read_state', { channel: 'kcd_store', op: 'save' } ) ).toContain( 'write-refused' );

		const wrote = await json( 'write_state', { channel: 'kcd_store', op: 'save', args: { path: 'a.html' } } );
		expect( wrote[ 'value' ] ).toEqual( { asked: { path: 'a.html' } } );
		expect( app.asked.at( -1 ) ).toMatchObject( { verb: 'kcd_store.save', mode: 'pull' } );
	} );

	it( 'reports a declared-but-unarmed channel as a fact about THIS RUN, not about the source', async () => {
		// The distinction that decides where someone looks next: `project_store` IS declared, so the
		// source is fine and the service did not arm. Reading that as "not declared" sends a person to
		// edit a registry that is already correct.
		const text = await refusal( 'read_state', { channel: 'project_store', op: 'list' } );
		expect( text ).toContain( 'unarmed' );
		expect( text ).not.toContain( 'unregistered' );
		expect( text ).toContain( 'the app answered' );
	} );

	it( 'passes the argument object through the lane unchanged', async () => {
		const body = await json( 'read_state', { channel: 'kcd_store', op: 'catalog', args: { path: 'x.html' } } );
		expect( body[ 'value' ] ).toEqual( { asked: { path: 'x.html' } } );
	} );

	// ── The seam itself ──────────────────────────────────────────────────────────────────────

	it( 'reports an unrouted verb as the app answering, not as the app being unreachable', async () => {
		// The single most expensive confusion available at this seam: a verb nothing serves is a FINDING
		// about the app — a service failed to arm, or the verb was renamed — whereas a refused socket
		// means no verb ran and nothing was tested. A second app with nothing scripted on it, so the
		// door genuinely returns `unrouted` rather than the harness pretending to.
		await app.stop();
		const bare = await new TestApp().listen();
		try {
			const text = await refusal( 'list_decisions' );
			expect( text ).toContain( 'unrouted' );
			expect( text ).toContain( 'the app answered' );
			expect( text ).not.toContain( 'NOTHING WAS TESTED' );
		} finally { await bare.stop(); }
	} );

	it( 'says NOTHING WAS TESTED when the app cannot be reached at all', async () => {
		await app.stop();
		process.env[ 'STARMIND_DEV_PORT' ] = '1';          // nothing listens on port 1
		const text = await refusal( 'list_sessions' );
		expect( text ).toContain( 'NOTHING WAS TESTED' );
		expect( text ).toContain( 'app-down' );
		// And it must NOT read as a finding about Starmind.
		expect( text ).not.toContain( 'unrouted' );
	} );
} );
